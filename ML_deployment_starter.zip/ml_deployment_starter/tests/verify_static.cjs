// Run from starter root: node tests/verify_static.cjs
const fs=require("node:fs"), path=require("node:path"), assert=require("node:assert/strict");
const root=path.resolve(__dirname,"..");
const {predictIris}=require(path.join(root,"static_space/predict.js"));
const model=JSON.parse(fs.readFileSync(path.join(root,"static_space/model.json"),"utf8"));
const refs=JSON.parse(fs.readFileSync(path.join(root,"reports/tree_reference_predictions.json"),"utf8"));
refs.rows.forEach((row,i)=>assert.equal(predictIris(model,row).class_id,refs.class_ids[i]));
for(const row of [[1,2,3], [1,2,3,NaN], [1,2,3,Infinity], [1,2,3,-1], [1,2,3,0], [1,2,3,21], [1,2,3,"4"]]) {
  assert.throws(()=>predictIris(model,row));
}
const output={scope:"Local JS-versus-Python parity, not hosted verification",
  parity_inputs:refs.rows.length,parity_matches:refs.rows.length,invalid_inputs_rejected:7};
fs.writeFileSync(path.join(root,"reports/static_verification.json"),JSON.stringify(output,null,2)+"\n");
console.log(output);
