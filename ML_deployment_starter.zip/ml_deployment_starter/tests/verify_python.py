"""Run from starter root: python tests/verify_python.py"""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"gradio_space"))
from inference import predict_iris
from app import demo, predict_ui

examples=[([5.1,3.5,1.4,0.2],"setosa"),([6.0,2.9,4.5,1.5],"versicolor"),
          ([6.5,3.0,5.8,2.2],"virginica")]
for values,expected in examples:
    scores=predict_iris(*values)
    assert max(scores,key=scores.get)==expected
    assert abs(sum(scores.values())-1)<1e-10
    assert scores==predict_ui(*values)
invalid=[[1,2,3,None],[1,2,3,float("nan")],[1,2,3,float("inf")],
         [1,2,3,-1],[1,2,3,0],[1,2,3,21],[1,2,3,"4"]]
for values in invalid:
    try: predict_iris(*values)
    except ValueError: pass
    else: raise AssertionError(f"Invalid input accepted: {values}")
assert demo.config["components"]
result={"scope":"Local Python inference/UI construction, not hosted verification",
        "example_predictions_passed":len(examples),"invalid_inputs_rejected":len(invalid),
        "gradio_interface_constructed":True}
(ROOT/"reports/python_verification.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
