# ML deployment practical starter

This package accompanies the ML deployment guide. It contains two real artifacts
from training, complete source code, and local test evidence. There are no quiz
answers or credentials. Use the **free static path** for the required deployment.

## Quick start: free HTML/JavaScript Space

1. Extract this ZIP and open a terminal inside `ml_deployment_starter`.
2. Install Python 3.12 and, for the parity test, Node.js 18 or later.
3. Create a virtual environment:

```bash
python -m venv .venv
```

Activate it on macOS/Linux: `source .venv/bin/activate`.
Activate it on Windows PowerShell: `.venv\Scripts\Activate.ps1`.
If `python` is not found, use `python3` (macOS/Linux) or `py -3.12` (Windows)
for the environment-creation command, then use `python` inside the environment.

```bash
python -m pip install -r training/requirements.txt
python training/train_models.py
node tests/verify_static.cjs
python -m http.server 8000 --directory static_space
```

4. Open http://localhost:8000, click Predict species, and test all three examples.
5. Create a Hugging Face **Static** Space in your own account.
6. Upload the five files **inside static_space/** to its repository root:
   README.md, index.html, app.js, predict.js, model.json. Preserve the YAML at the
   very top of README.md. Do not upload the ZIP itself as the app.
7. Wait for the Space to show Ready/Running. Test its App tab and save the URL,
   prediction screenshots, invalid-input evidence, and the deployed revision.

The supplied JSON also lets you preview without installing scikit-learn; to meet
the full lab workflow, run training yourself and retain your evaluation report.
The browser runs inference. The static host cannot execute Python or load joblib.

## Optional Python / Gradio path

Only after the primary path works:

```bash
python -m pip install -r gradio_space/requirements.txt
python tests/verify_python.py
python gradio_space/app.py
```

Open the local URL printed by Gradio. Stop a server with Ctrl+C.
Hosting this extension requires suitable account eligibility under current HF
compute rules. Do not pay for a plan for this lab. Static Spaces are the required
free path. Follow gradio_space/README.md if your account already supports Gradio.

## Model and data contract

Both examples use scikit-learn Iris (150 rows, three species) and the same
stratified 120/30 train/test split with random_state=42. Feature order:
`[sepal_length_cm, sepal_width_cm, petal_length_cm, petal_width_cm]`.
All four values must be finite, greater than 0 and at most 20.

- **Static:** DecisionTreeClassifier(max_depth=3, random_state=42), exported to
  model.json. JavaScript follows the saved split thresholds; it does not fit.
- **Python:** StandardScaler + LogisticRegression(max_iter=500, random_state=42),
  saved together in model.joblib. The scaler is fit only on training data.
- Local metrics and split indices are in reports/metrics.json. Hosted success
  must be established separately after your own upload. A correct deployment can
  still give a wrong prediction. Do not tune repeatedly against the final test set.
- Only load joblib artifacts you created or whose source you fully trust: loading
  can execute code. Keep the exact persistence-related package versions pinned.
- Public Spaces expose their source/model files. Never put passwords, personal
  data, HF tokens, or other secrets in HTML, JavaScript, JSON, or public repos.
  This lab needs no API token and no external inference provider.

## Folder map

- training/: reproducible train/evaluate/save script and pinned dependencies.
- static_space/: upload these five files for the required free Space.
- gradio_space/: optional Python UI, trained pipeline and metadata.
- tests/: JavaScript parity and Python inference checks.
- reports/: local evaluation, reference predictions and verification results.

## Troubleshooting

- **404/model cannot load:** put all five static files at repo root with exact
  spelling; keep the relative `./model.json` path. Do not nest static_space/.
- **Blank app:** verify sdk: static and app_file: index.html in root README YAML;
  inspect browser console and wait for deployment. Refresh after the new revision.
- **Works locally, wrong class online:** compare deployed model.json, script
  revision, feature order, cm units and cached files; use the fixed examples.
- **fetch blocked locally:** use http.server; do not double-click file:// HTML.
- **joblib/version error:** recreate the venv and reinstall exact pinned versions;
  regenerate your own model with the same environment. Never load an unknown file.
- **Paid-plan prompt:** select Static. The assignment does not require compute.
- **Privacy:** use only the educational Iris data. A browser-based app is public
  code, so secrets cannot be hidden inside it.

## Authoritative references (checked October 25, 2026)

- https://huggingface.co/docs/hub/spaces-overview
- https://huggingface.co/docs/hub/spaces-sdks-static
- https://huggingface.co/docs/hub/spaces-config-reference
- https://huggingface.co/docs/hub/spaces-sdks-gradio
- https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_iris.html
- https://scikit-learn.org/stable/modules/compose.html#pipeline
- https://scikit-learn.org/stable/model_persistence.html

Original instructional code in this starter is licensed under MIT. The Iris
dataset is supplied by scikit-learn; see its dataset description and attribution.
