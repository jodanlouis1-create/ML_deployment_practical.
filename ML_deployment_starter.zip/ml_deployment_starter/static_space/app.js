"use strict";
let model;
const form = document.getElementById("predict-form");
const button = document.getElementById("predict-button");
const result = document.getElementById("result");
const status = document.getElementById("status");
fetch("./model.json", {cache: "no-cache"})
  .then(response => {
    if (!response.ok) throw new Error(`model.json could not load (${response.status}).`);
    return response.json();
  })
  .then(data => {
    model = data;
    predictIris(model, [5.1, 3.5, 1.4, 0.2]); // format check before enabling UI
    button.disabled = false;
    status.textContent = "Trained model loaded. Ready for inference in your browser.";
  })
  .catch(error => {
    status.textContent = `Model load failed: ${error.message} Check the root files.`;
  });
form.addEventListener("submit", event => {
  event.preventDefault();
  try {
    const values = ["sl", "sw", "pl", "pw"].map(id => {
      const text = document.getElementById(id).value.trim();
      return text === "" ? NaN : Number(text);
    });
    const prediction = predictIris(model, values);
    result.textContent = `Predicted species: ${prediction.label}. ` +
      `Training examples in this leaf: ${prediction.leaf_samples}. ` +
      `Leaf class shares: ${model.classes.map((name, i) =>
        `${name} ${(100 * prediction.scores[i]).toFixed(1)}%`).join(", ")}. ` +
      "These shares are not calibrated confidence.";
  } catch (error) { result.textContent = error.message; }
});
document.querySelectorAll("[data-values]").forEach(button => {
  button.addEventListener("click", () => {
    const values = JSON.parse(button.dataset.values);
    ["sl", "sw", "pl", "pw"].forEach((id, i) => document.getElementById(id).value = values[i]);
    result.textContent = "Example loaded. Click Predict species.";
  });
});
