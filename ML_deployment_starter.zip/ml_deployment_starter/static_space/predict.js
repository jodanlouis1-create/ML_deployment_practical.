(function (root) {
  "use strict";
  function predict(model, values) {
    if (model.schema_version !== 1 || model.model_type !== "decision_tree_classifier") {
      throw new Error("Unsupported model format. Use the lab model.json.");
    }
    if (!Array.isArray(values) || values.length !== 4 ||
        values.some(v => typeof v !== "number" || !Number.isFinite(v) || v <= 0 || v > 20)) {
      throw new Error("Enter four finite numbers in cm, each greater than 0 and at most 20.");
    }
    // sklearn's DecisionTreeClassifier casts prediction input to float32.
    const x = values.map(Math.fround);
    let node = model.tree;
    while (node.feature !== undefined) {
      node = x[node.feature] <= node.threshold ? node.left : node.right;
    }
    return {class_id: node.class_id, label: model.classes[node.class_id],
            scores: node.scores, leaf_samples: node.training_samples};
  }
  root.predictIris = predict;
  if (typeof module !== "undefined" && module.exports) module.exports = {predictIris: predict};
})(typeof globalThis !== "undefined" ? globalThis : this);
