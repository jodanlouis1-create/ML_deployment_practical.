---
title: Iris ML Deployment Lab
emoji: 🌸
colorFrom: blue
colorTo: green
sdk: static
app_file: index.html
pinned: false
license: mit
---

# Iris ML Deployment Lab - Static HTML and JavaScript

An educational classifier trained **before deployment** with scikit-learn.
The browser downloads `model.json` and traverses its trained decision tree.
No server, API token, Python runtime, or paid compute is required by this app.
This small JSON format supports this decision tree only; it is not a general
converter for arbitrary scikit-learn estimators.

Upload the **contents** of this folder to the root of a Hugging Face Space
created with the **Static** SDK: README.md, index.html, app.js, predict.js,
and model.json. Do not upload the parent starter folder as a nested directory.

Inputs, in order: sepal length, sepal width, petal length, petal width, all in cm.
Each must be a finite number greater than 0 and at most 20. These broad lab
bounds do not establish that an input is biologically plausible.
The result is one of setosa, versicolor, and virginica. Leaf scores describe
the training examples in that leaf; they are not calibrated certainty.

Local preview, from the extracted starter root:

```bash
python -m http.server 8000 --directory static_space
```

Open http://localhost:8000. Opening index.html as file:// may block fetch.
To regenerate the artifact, follow the parent README and run training/train_models.py.
Test your hosted app after it reports Ready/Running and save evidence of a
successful prediction, source files, and invalid-input handling. This package
contains local checks; it does not claim a hosted deployment was performed.

Source: https://huggingface.co/docs/hub/spaces-sdks-static
