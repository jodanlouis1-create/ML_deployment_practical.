"""Train once, evaluate on a held-out split, save two deployable artifacts.
Run from the extracted starter root: python training/train_models.py
The serving apps never train a model. Only load trusted joblib files.
"""
from pathlib import Path
import hashlib, importlib.metadata, json, platform
import joblib
import numpy as np
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parents[1]
DATA = load_iris()
FEATURES = ["sepal_length_cm", "sepal_width_cm", "petal_length_cm", "petal_width_cm"]
CLASSES = DATA.target_names.tolist()
indices = np.arange(len(DATA.target))
train_idx, test_idx = train_test_split(indices, test_size=0.2, random_state=42,
                                     stratify=DATA.target)
X_train, y_train = DATA.data[train_idx], DATA.target[train_idx]
X_test, y_test = DATA.data[test_idx], DATA.target[test_idx]
tree = DecisionTreeClassifier(max_depth=3, random_state=42).fit(X_train, y_train)
pipeline = make_pipeline(StandardScaler(),
                        LogisticRegression(max_iter=500, random_state=42))
pipeline.fit(X_train, y_train)
versions = {p: importlib.metadata.version(p) for p in
            ["numpy", "scipy", "scikit-learn", "joblib", "threadpoolctl"]}

def node(i):
    t = tree.tree_
    if t.children_left[i] == t.children_right[i]:
        counts = t.value[i][0].astype(float)
        return {"class_id": int(tree.classes_[np.argmax(counts)]),
                "scores": (counts/counts.sum()).tolist(),
                "training_samples": int(t.n_node_samples[i])}
    return {"feature": int(t.feature[i]), "threshold": float(t.threshold[i]),
            "left": node(int(t.children_left[i])),
            "right": node(int(t.children_right[i]))}

static = ROOT/"static_space"; gradio = ROOT/"gradio_space"; reports=ROOT/"reports"
for d in [static, gradio, reports]: d.mkdir(exist_ok=True)
artifact = {"schema_version": 1, "model_type": "decision_tree_classifier",
            "feature_names": FEATURES, "units": "cm", "classes": CLASSES,
            "input_bounds": {"exclusive_min": 0, "inclusive_max": 20},
            "input_cast": "float32", "tree": node(0),
            "training": {"random_state": 42, "max_depth": 3,
                         "train_count": len(train_idx), "test_count": len(test_idx),
                         "versions": versions}}
(static/"model.json").write_text(json.dumps(artifact, indent=2)+"\n")
joblib.dump(pipeline, gradio/"model.joblib", compress=3)
metadata={"feature_names": FEATURES, "units": "cm", "classes": CLASSES,
          "input_bounds": {"exclusive_min":0,"inclusive_max":20},
          "model_type":"StandardScaler + LogisticRegression", "versions":versions}
(gradio/"metadata.json").write_text(json.dumps(metadata,indent=2)+"\n")

def metrics(model):
    pred=model.predict(X_test)
    return {"accuracy":float(accuracy_score(y_test,pred)),
            "macro_f1":float(f1_score(y_test,pred,average="macro")),
            "confusion_matrix":confusion_matrix(y_test,pred,labels=[0,1,2]).tolist()}
examples = [[5.1,3.5,1.4,0.2],[6.0,2.9,4.5,1.5],[6.5,3.0,5.8,2.2]]
report={"scope":"Local held-out evaluation, not hosted Hugging Face verification",
        "dataset":"scikit-learn load_iris; 150 rows; 3 classes; 4 cm features",
        "split":{"test_size":0.2,"random_state":42,"stratified":True,
                 "train_count":len(train_idx),"test_count":len(test_idx),
                 "train_indices":train_idx.tolist(),"test_indices":test_idx.tolist()},
        "versions":versions,"python":platform.python_version(),
        "decision_tree":metrics(tree),"scaled_logistic_regression":metrics(pipeline),
        "examples":[{"input":x,"tree":CLASSES[int(tree.predict([x])[0])],
                     "logistic":CLASSES[int(pipeline.predict([x])[0])]} for x in examples],
        "sha256":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in [static/"model.json",gradio/"model.joblib"]}}
(reports/"metrics.json").write_text(json.dumps(report,indent=2)+"\n")
# Reference Python predictions used to test the exported browser evaluator.
rng=np.random.default_rng(42)
random_rows=rng.uniform([4,2,1,0.1],[8,4.5,7,2.5],size=(500,4))
threshold_rows=[]
for i in range(tree.tree_.node_count):
    f=int(tree.tree_.feature[i])
    if f>=0:
        t=np.float32(tree.tree_.threshold[i])
        for v in [np.nextafter(t,np.float32(-np.inf)), t,
                  np.nextafter(t,np.float32(np.inf))]:
            x=DATA.data[0].copy(); x[f]=float(v); threshold_rows.append(x)
rows=np.vstack([DATA.data,random_rows,np.asarray(threshold_rows)])
refs={"rows":rows.tolist(),"class_ids":tree.predict(rows).astype(int).tolist(),
      "scope":"All 150 Iris rows, 500 synthetic inputs, float32 neighbors at each split"}
(reports/"tree_reference_predictions.json").write_text(json.dumps(refs,indent=2)+"\n")
print(json.dumps({"decision_tree":report["decision_tree"],
                  "scaled_logistic_regression":report["scaled_logistic_regression"],
                  "examples":report["examples"]},indent=2))
