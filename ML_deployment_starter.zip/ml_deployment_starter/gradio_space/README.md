---
title: Iris Python Deployment Lab
emoji: 🌸
colorFrom: indigo
colorTo: green
sdk: gradio
sdk_version: 5.49.1
python_version: "3.12"
app_file: app.py
pinned: false
license: mit
---

# Optional Python extension

This uses the trained `StandardScaler + LogisticRegression` pipeline in
`model.joblib`, loaded once at process startup. There is no training in app.py.
The full inference contract is in metadata.json and inference.py.

**Hosting eligibility:** As checked October 25, 2026, Hugging Face documents
paid-plan requirements for creating compute-backed Gradio/Docker Spaces;
free personal accounts in good standing may have limited ZeroGPU eligibility.
Do not buy compute for this lab. The required static path is free.
Run this optional extension locally unless your account already has suitable
hosting eligibility. Recheck current rules before any hosted use.

```bash
python -m pip install -r gradio_space/requirements.txt
python gradio_space/app.py
```

From the starter root, open the local URL printed by Gradio (normally
http://127.0.0.1:7860). The app has share=False and does not create a public tunnel.
For an eligible Gradio Space, upload this folder's contents to repository root.
Do not upload training code, a virtual environment, or secrets.

**Only load a joblib file you trained yourself or obtained from a trusted,
verified source. Joblib is pickle based and loading can execute arbitrary code.**
Use the same scikit-learn/numpy/scipy/joblib versions used in training; replacing
requirements with unpinned latest versions can break persistence compatibility.

Sources:
- https://huggingface.co/docs/hub/spaces-overview
- https://huggingface.co/docs/hub/spaces-sdks-gradio
- https://scikit-learn.org/stable/model_persistence.html
