"""Python UI for an already trained model. No .fit() call belongs here."""
import gradio as gr
from inference import predict_iris

def predict_ui(*values):
    try:
        return predict_iris(*values)
    except ValueError as exc:
        raise gr.Error(str(exc)) from exc

demo=gr.Interface(
    fn=predict_ui,
    inputs=[gr.Number(label=label, value=value) for label,value in
            zip(["Sepal length (cm)","Sepal width (cm)","Petal length (cm)","Petal width (cm)"],
                [5.1,3.5,1.4,0.2])],
    outputs=gr.Label(label="Predicted class scores (not calibrated certainty)"),
    title="Iris: saved Python model inference",
    description="A saved StandardScaler + LogisticRegression pipeline. Four positive cm measurements, each <=20.",
    examples=[[5.1,3.5,1.4,0.2],[6.0,2.9,4.5,1.5],[6.5,3.0,5.8,2.2]],
    flagging_mode="never")

if __name__=="__main__":
    demo.launch(share=False)
