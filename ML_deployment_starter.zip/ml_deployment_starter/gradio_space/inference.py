"""Pure inference function; no UI and no training side effects."""
from pathlib import Path
import json, math
import joblib
import numpy as np

HERE = Path(__file__).resolve().parent
METADATA = json.loads((HERE/"metadata.json").read_text())
# Security: load ONLY this lab's trusted artifact or your own trained artifact.
MODEL = joblib.load(HERE/"model.joblib")

def predict_iris(sepal_length, sepal_width, petal_length, petal_width):
    values=[sepal_length,sepal_width,petal_length,petal_width]
    if any(isinstance(v, bool) or not isinstance(v, (int,float,np.number))
           or not math.isfinite(v) or v<=0 or v>20 for v in values):
        raise ValueError("Enter four finite numbers in cm, each greater than 0 and at most 20.")
    x=np.asarray([values], dtype=float) # same feature order, one sample / four columns
    scores=MODEL.predict_proba(x)[0]
    labels=METADATA["classes"]
    return {labels[int(c)]:float(p) for c,p in zip(MODEL.classes_,scores)}
